# Image Overlay Tool

A web-based image editor built with Fabric.js that allows users to add text overlays, banners, and other elements to images.

## Features

- **Image Upload**: Upload and edit images with drag-and-drop support
- **Text Overlays**: Add customizable text with various fonts, colors, and alignments
- **Banner Overlays**: Add pre-designed banner overlays
- **Logo Placement**: Add and position logos
- **Export Options**:
  - **PNG Export**: Export as high-quality PNG images
  - **PSD Export**: Export as Photoshop-compatible PSD files with editable layers

## PSD Export Feature

The PSD export functionality allows users to download their edited images as Photoshop-compatible PSD files. This feature:

- **Preserves Layers**: Each element (text, images, overlays) becomes a separate layer
- **Maintains Positioning**: All elements retain their exact positions
- **Editable Text**: Text layers remain editable in Photoshop
- **Layer Naming**: Layers are intelligently named (e.g., "Main Image", "Banner Overlay", "Text: Actor Portrayal")
- **Opacity Support**: Layer opacity is preserved
- **High Quality**: Maintains the original image quality

### How to Use PSD Export

1. Upload and edit your image as usual
2. Add text overlays, banners, or other elements
3. Click the "Export PSD" button (brown button next to the PNG export)
4. The PSD file will download automatically
5. Open the PSD file in Adobe Photoshop or any compatible image editor

### Technical Details

- Uses the `ag-psd` library for PSD generation
- Works entirely client-side (no server processing required)
- Supports both featured images (1200x600) and actor images (160x160)
- Handles various object types: images, text, rectangles
- Includes loading states and error handling

## Installation

1. Clone the repository
2. Install dependencies: `npm install`
3. Start the server: `npm start`
4. Open `http://localhost:3133` in your browser

## Dependencies

- Express.js (static file server)
- Fabric.js (canvas manipulation)
- ag-psd (PSD file generation)

## Browser Compatibility

The PSD export feature works in all modern browsers that support:

- ES6+ JavaScript
- Canvas API
- Blob API
- File downloads
