/* TOOL TIP */

const tooltip = document.querySelectorAll("[data-tip]");

tooltip.forEach((tooltip) => {
	const tooltipText = tooltip.dataset.tip;
	const tooltipElement = document.createElement("div");
	tooltipElement.className = "tooltip";
	tooltipElement.innerText = tooltipText;
	document.body.appendChild(tooltipElement);

	tooltip.addEventListener("mouseenter", () => {
		const tooltipPosition = tooltip.getBoundingClientRect();
		const tooltipWidth = tooltipElement.offsetWidth;
		const tooltipHeight = tooltipElement.offsetHeight;
		const screenWidth = window.innerWidth;
		const screenHeight = window.innerHeight;

		let top = tooltipPosition.top - tooltipHeight - 30;
		let left =
			tooltipPosition.left + tooltipPosition.width / 2 - tooltipWidth / 2;

		if (top < 0) {
			top = tooltipPosition.top + tooltipPosition.height + 10;
			tooltipElement.classList.add("bottom");
		}

		if (left < 0) {
			left = 0;
		} else if (left + tooltipWidth > screenWidth) {
			left = screenWidth - tooltipWidth;
		}

		tooltipElement.style.top = `${top}px`;
		tooltipElement.style.left = `${left}px`;
		tooltipElement.classList.add("show");
	});

	tooltip.addEventListener("mouseleave", () => {
		tooltipElement.classList.remove("show");
		tooltipElement.classList.remove("bottom");
	});
});
