document.addEventListener('DOMContentLoaded', () => {
  const canvas = new fabric.Canvas('canvas');
  let mainImage;
  let overlayImage;
  let textBoxes = [];
  let logoImage = null;
  let backgroundRect = null;

  const actorCanvas = new fabric.Canvas('actorCanvas');
  let isActorImage = false;

  const featuredControls = document.getElementById('featuredImageControls');
  const mainCanvasElement = document.getElementById('canvas');
  const actorCanvasElement = document.getElementById('actorCanvas');
  const mainCanvasContainer = document.querySelector('.canvas-container:first-of-type');
  const actorCanvasContainer = document.querySelector('.canvas-container:last-of-type');
  const pageHeader = document.querySelector('h2.page-header');

  // actor image checkbox
  document.getElementById('isActorImage').addEventListener('change', function (e) {
    isActorImage = e.target.checked;

    if (isActorImage) {
      featuredControls.style.display = 'none';
      mainCanvasElement.style.display = 'none';
      actorCanvasElement.style.display = 'block';
      mainCanvasContainer.style.display = 'none';
      actorCanvasContainer.style.display = 'block';
      pageHeader.innerHTML = 'Actor Image';


      // reset the actor canvas dimensions
      actorCanvas.setDimensions({
        width: 160,
        height: 160
      });

      // if there's an existing image, resize it for actor mode
      if (mainImage) {
        const img = mainImage.getElement();
        fabric.Image.fromURL(img.src, (img) => {
          img.scaleToHeight(150);
          img.scaleToWidth(150);

          // center the image in the 160x160 canvas
          img.set({
            left: (160 - img.getScaledWidth()) / 2,
            top: (160 - img.getScaledHeight()) / 2,
            selectable: true,
            hasControls: true,
            hasBorders: true,
            lockMovementX: false,
            lockMovementY: false,
          });

          img.setControlsVisibility({
            tl: true, // top-left
            tr: true, // top-right
            bl: true, // bottom-left
            br: true, // bottom-right
            ml: false, // middle-left
            mt: false, // middle-top
            mr: false, // middle-right
            mb: false, // middle-bottom
            mtr: false // middle-top rotate
          });
          actorCanvas.clear();
          actorCanvas.add(backgroundRect);
          actorCanvas.add(img);
          actorCanvas.renderAll();
        });
      }
    } else {
      featuredControls.style.display = 'flex';
      mainCanvasElement.style.display = 'block';
      actorCanvasElement.style.display = 'none';
      mainCanvasContainer.style.display = 'block';
      actorCanvasContainer.style.display = 'none';
      pageHeader.innerHTML = 'Featured Image Creator';

      // reset the main canvas dimensions
      canvas.setDimensions({
        width: 1200,
        height: 600
      });

      // restore the main image if it exists
      if (mainImage) {
        canvas.clear();
        canvas.add(mainImage);
        customRender();
      }
    }
  });

  // modified image upload handler
  document.getElementById('image').addEventListener('change', function (e) {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = function (event) {
      fabric.Image.fromURL(event.target.result, (img) => {
        if (isActorImage) {
          // handle actor image

          img.scaleToHeight(150);
          img.scaleToWidth(150);
          // img.classList.add('.actor');

          // center the image in the 160x160 canvas
          img.set({
            left: (160 - img.getScaledWidth()) / 2,
            top: (160 - img.getScaledHeight()) / 2
          });

          actorCanvas.clear();
          actorCanvas.add(img);
          actorCanvas.renderAll();
        } else {
          // handle featured image
          mainImage = img;
          mainImageOptions(mainImage);
          customRender();
        }

        // show resize button
        document.getElementById('resize').style.display = 'inline-block';
      });
    };
    reader.readAsDataURL(file);
  });
  // create bg rectangle function
  function createBackground() {
    if (mainImage) {
      // remove existing bg if any
      if (backgroundRect) {
        canvas.remove(backgroundRect);
      }

      // create new bg
      backgroundRect = new fabric.Rect({
        left: mainImage.left || 0,
        top: mainImage.top || 0,
        width: mainImage.width * (mainImage.scaleX || 1),
        height: mainImage.height * (mainImage.scaleY || 1),
        fill: 'white',
        selectable: false,
        evented: false
      });
    }
  }

  // main image
  function mainImageOptions(object) {
    object.set({
      selectable: true,
      hasControls: true,
      hasBorders: true,
      lockMovementX: false,
      lockMovementY: false,
    });
    object.setControlsVisibility({
      tl: true, // top-left
      tr: true, // top-right
      bl: true, // bottom-left
      br: true, // bottom-right
      ml: false, // middle-left
      mt: false, // middle-top
      mr: false, // middle-right
      mb: false, // middle-bottom
      mtr: false // middle-top rotate
    });
  }

  function moveToTop(obj) {
    if (obj && obj !== mainImage) {
      obj.moveTo(canvas.getObjects().length - 1);
      console.log(obj)
    }
  }

  // to ensure correct stacking order
  function customRender() {
    canvas.clear();
    createBackground();
    if (backgroundRect) canvas.add(backgroundRect);
    if (mainImage) canvas.add(mainImage);
    if (overlayImage) canvas.add(overlayImage);
    if (logoImage) canvas.add(logoImage);
    if (featherMask) canvas.add(featherMask);
    textBoxes.forEach(text => canvas.add(text));
    canvas.renderAll();
  }

  // image moving
  canvas.on('object:modified', function (e) {
    if (e.target === mainImage) {
      moveToTop(overlayImage);
      customRender();
    }
  });

  // select text boxes
  canvas.on('object:selected', function (e) {
    const selectedObject = e.target;
    if (selectedObject.type === 'i-text') {
      moveToTop(selectedObject);
    } else if (selectedObject === overlayImage) {
      moveToTop(overlayImage);
    }
  });

  // image upload
  // document.getElementById('image').addEventListener('change', function (e) {
  //   const file = e.target.files[0];
  //   const reader = new FileReader();
  //   console.log("second")
  //   reader.onload = function (event) {
  //     fabric.Image.fromURL(event.target.result, (img) => {
  //       mainImage = img;
  //       mainImageOptions(mainImage);
  //       createBackground();
  //       customRender();
  //       // show resize btn
  //       document.getElementById('resize').style.display = 'inline-block';
  //     });
  //   };
  //   reader.readAsDataURL(file);
  // });

  // overlay selection
  document.getElementById('overlays').addEventListener('change', function (e) {
    const selectedOverlay = e.target.value;
    console.log(selectedOverlay)

    if (selectedOverlay !== 'default') {
      if (!overlayImage) {
        overlayImage = new fabric.Image(null, {
          selectable: true,
          hasControls: true,
          hasBorders: true,
          lockMovementX: false,
          lockMovementY: false,
          originX: 'left',
          originY: 'top',
        });
      }

      overlayImage.setSrc(`/overlays/${selectedOverlay}`, () => {
        moveToTop(overlayImage);
        customRender();
      });
    } else {
      // remove any existing overlay
      if (overlayImage) {
        canvas.remove(overlayImage);
        overlayImage = null;
      }
      customRender();
    }
  });

  // logos
  document.getElementById('logos').addEventListener('change', function (e) {
    const selectedLogo = e.target.value;
    console.log(selectedLogo);

    if (selectedLogo !== 'default') {
      if (!logoImage) {
        logoImage = new fabric.Image(null, {
          selectable: true,
          hasControls: true,
          hasBorders: true,
          lockMovementX: false,
          lockMovementY: false,
          originX: 'right',
          originY: 'bottom',
          top: 570,
          left: 1170,
        });
      }

      logoImage.setSrc(`/logos/${selectedLogo}`, () => {
        moveToTop(logoImage);
        customRender();
      });
    } else {
      // Remove any existing logo
      if (logoImage) {
        canvas.remove(logoImage);
        logoImage = null;
      }
      customRender();
    }
  });

  // text boxes - just add text
  // document.getElementById('add').addEventListener('click', function () {
  //   const bold = document.getElementById('weight').checked;
  //   addTextBox('Actor Portrayal', 935, 525, 32, 'arial', '#000000', bold);
  // });

  function addTextBox(txt, left, top, fontSize, fontFamily, fill, bold) {
    const maxWidth = 225; // max width for text wrapping
    const lineHeight = 1.2; // line height factor

    const textLines = [];
    const words = txt.split(' ');
    let currentLine = '';

    words.forEach(word => {
      const testLine = currentLine.length > 0 ? currentLine + ' ' + word : word;
      const width = canvas.getContext().measureText(testLine).width;

      if (width < maxWidth) {
        currentLine = testLine;
      } else {
        textLines.push(currentLine);
        currentLine = word;
      }
    });

    textLines.push(currentLine);

    const text = new fabric.Textbox(textLines.join('\n'), {
      left: left,
      top: top,
      fontSize: fontSize,
      fontFamily: fontFamily,
      fill: fill,
      lineHeight: lineHeight,
      width: maxWidth,
      lockScalingX: false,
      fontWeight: bold ? 'bold' : 'normal',
    });

    moveToTop(text);
    textBoxes.push(text);

    customRender();
  }

  // change text color
  document.getElementById('text-color').addEventListener('change', function (e) {
    const selectedColor = e.target.value;
    const activeObject = canvas.getActiveObject();
    if (activeObject && (activeObject.type === 'i-text' || activeObject.type === 'textbox')) {
      activeObject.set('fill', selectedColor);
      canvas.renderAll();
    }
  });

  // change text boldness
  document.getElementById('weight').addEventListener('change', function (e) {
    const bold = e.target.checked;
    const activeObject = canvas.getActiveObject();
    if (activeObject && (activeObject.type === 'i-text' || activeObject.type === 'textbox')) {
      activeObject.set('fontWeight', bold ? 'bold' : 'normal');
      canvas.renderAll();
    }
  });

  // remove box
  document.getElementById('remove').addEventListener('click', function () {
    const activeObject = canvas.getActiveObject();
    if (activeObject && (activeObject.type === 'i-text' || activeObject.type === 'textbox')) {
      canvas.remove(activeObject);
      const index = textBoxes.indexOf(activeObject);
      if (index !== -1) {
        textBoxes.splice(index, 1);
      }
      // canvas.renderAll();
      customRender();
    }
  });

  // toggle showing the prefilled text options div when the "Text" button is clicked
  document.getElementById('add').addEventListener('click', () => {
    // document.getElementById('prefilled-text-options').style.display = 'block';
    document.getElementById('add').classList.toggle("text-options-active");
    document.getElementById('prefilled-text-options').classList.toggle('show');
  });

  // text options (prefilled)
  const textOptionButtons = document.querySelectorAll('.text-option');
  textOptionButtons.forEach(button => {
    button.addEventListener('click', function () {
      const selectedText = this.getAttribute('data-text');
      addTextBox(selectedText, 935, 525, 32, 'arial', '#000000', false);
      // document.getElementById('prefilled-text-options').style.display = 'none';
      document.getElementById('prefilled-text-options').classList.toggle('show');
    });
  });

  // custom text selection
  document.getElementById('custom-text-option').addEventListener('click', () => {
    let customInputHeader = document.querySelector('.custom-header');

    const customInput = document.getElementById('custom-text-input');
    customInput.style.display = 'block';
    customInputHeader.style.display = 'block';
    customInput.focus();

    customInput.addEventListener('keyup', function (e) {
      if (e.key === 'Enter') {
        const customText = customInput.value;
        if (customText) {
          addTextBox(customText, 935, 525, 32, 'arial', '#000000', false);
          // document.getElementById('prefilled-text-options').style.display = 'none';
          document.getElementById('prefilled-text-options').classList.toggle('show');
          customInput.style.display = 'none';
          customInput.value = '';
          customInputHeader.style.display = 'none';
        }
      }
    });
  });

  // resize image button
  document.getElementById('resize').addEventListener('click', function () {
    if (mainImage) {
      mainImage.scaleToWidth(1210);
      createBackground();
      customRender();
    }
  });

  // feather mask
  let featherMask = null;

  document.getElementById('feather').addEventListener('change', function (e) {
    const featherOption = e.target.value;
    console.log("Selected feather option:", featherOption);
    applyFeatherMask(featherOption);
  });

  function applyFeatherMask(option) {
    if (mainImage) {
      console.log("Applying feather mask...");
      if (option !== 'none') {
        createFeatherMask(option);
      } else {
        removeFeatherMask();
      }
    }
  }

  function createFeatherMask(option) {
    console.log("Creating feather mask with option:", option);
    const gradient = createGradient(option);
    featherMask = new fabric.Rect({
      left: 0,
      top: 0,
      width: mainImage.width,
      height: mainImage.height,
      fill: gradient,
      selectable: false,
      evented: false
    });
    canvas.add(featherMask);
    moveToTop(featherMask);
    customRender();
  }

  function createGradient(option) {
    console.log("Creating gradient with option:", option);
    const gradient = new fabric.Gradient({
      type: 'linear',
      coords: { x1: 0, y1: mainImage.height, x2: 0, y2: 400 },
      colorStops: [
        { offset: 0, color: option === 'black' ? 'rgba(0,0,0,0.8)' : 'rgba(255,255,255,0.5)' },
        { offset: 1, color: option === 'black' ? 'rgba(0,0,0,0)' : 'rgba(255,255,255,0)' }
      ]
    });
    return gradient;
  }

  function removeFeatherMask() {
    if (featherMask) {
      console.log("Removing feather mask...");
      canvas.remove(featherMask);
      mainImage.set('globalCompositeOperation', 'source-over');
      canvas.renderAll();
      featherMask = null;
    }
  }


  // save image
  document.getElementById('export').addEventListener('click', function () {
    const activeCanvas = isActorImage ? actorCanvas : canvas;
    activeCanvas.discardActiveObject();

    const dataURL = activeCanvas.toDataURL({
      format: 'png',
      quality: 1,  // quality to 1 for MAXIUMUM QUALITY!#%
      backgroundColor: 'white',
      width: isActorImage ? 160 : 1200,
      height: isActorImage ? 160 : 600
    });

    const link = document.createElement('a');
    link.href = dataURL;
    link.download = isActorImage ? 'actor-image.png' : 'featured-image.png';
    link.click();
  });

  const textOptionsToggle = document.getElementById('text-options-toggle');
  const textOptionsMenu = document.getElementById('text-options-menu');

  textOptionsToggle.addEventListener('click', () => {
    textOptionsToggle.classList.toggle("active");
    textOptionsMenu.classList.toggle('show');
  });

  // alignments
  document.getElementById('align-left').addEventListener('click', function () {
    alignText('left');
  });

  document.getElementById('align-center').addEventListener('click', function () {
    alignText('center');
  });

  document.getElementById('align-right').addEventListener('click', function () {
    alignText('right');
  });

  function alignText(alignment) {
    const activeObject = canvas.getActiveObject();
    if (activeObject && (activeObject.type === 'i-text' || activeObject.type === 'textbox')) {
      activeObject.set('textAlign', alignment);
      canvas.renderAll();
    }
  }
});

