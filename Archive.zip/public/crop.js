
document.addEventListener('DOMContentLoaded', () => {
  const canvas = new fabric.Canvas('canvas');
  let mainImage;
  let overlayImage;
  let textBoxes = [];
  let logoImage = null;
  let backgroundRect = null;
  let circleOverlay;

  const actorCanvas = new fabric.Canvas('actorCanvas', {
    backgroundColor: 'white'
  });
  let isActorImage = false;
  let actorImageObject = null;
  let isActorCropping = false; // New state variable
  let cropRect; // To hold the cropping rectangle

  const featuredControls = document.getElementById('featuredImageControls');
  const mainCanvasElement = document.getElementById('canvas');
  const actorCanvasElement = document.getElementById('actorCanvas');
  const mainCanvasContainer = document.querySelector('.canvas-container:first-of-type');
  const actorCanvasContainer = document.getElementById('actorCanvasContainer'); // Get the container
  const pageHeader = document.querySelector('h2.page-header');


  const renderActorCanvasWithOverlayOnTop = () => {
    if (isActorImage && circleOverlay) {
      actorCanvas.discardActiveObject();
      const objects = actorCanvas.getObjects().filter(obj => obj !== circleOverlay);
      actorCanvas.clear();
      actorCanvas.add(...objects, circleOverlay);
      actorCanvas.renderAll();
    }
  };

  const actorControlsDiv = document.getElementById('actor-controls');

  // actor image checkbox
  document.getElementById('isActorImage').addEventListener('change', function (e) {
    isActorImage = e.target.checked;
    console.log("isActorImage:", isActorImage);

    if (isActorImage) {
      let upperCanvas = document.querySelector('.upper-canvas');
      let zoomControls = document.querySelector('#zoom-controls');

      featuredControls.style.display = 'none';
      mainCanvasElement.style.display = 'none';
      actorCanvasElement.style.display = 'block';
      mainCanvasContainer.style.display = 'none';
      actorCanvasContainer.style.display = 'block';

      actorControlsDiv.style.display = 'flex';
      zoomControls.style.display = 'flex';

      pageHeader.innerHTML = 'Actor Image';

      const actorUpperCanvas = actorCanvas.upperCanvasEl;
      if (actorUpperCanvas) {
        actorUpperCanvas.style.display = 'block';
        actorUpperCanvas.style.top = '20px';
      }

      actorCanvas.setDimensions({
        width: 160,
        height: 160
      });

      const createCircleOverlay = () => {
        circleOverlay = new fabric.Circle({
          radius: 80,
          left: actorCanvas.width / 2,
          top: actorCanvas.height / 2,
          originX: 'center',
          originY: 'center',
          fill: 'rgba(0, 0, 0, 0.3)',
          selectable: false,
          evented: false,
        });
        actorCanvas.add(circleOverlay);
        renderActorCanvasWithOverlayOnTop();
      };

      if (mainImage) {
        const img = mainImage.getElement();
        fabric.Image.fromURL(img.src, (loadedImg) => {
          loadedImg.originalSize = { width: loadedImg.width, height: loadedImg.height }; // Store original size
          actorImageObject = loadedImg;
          configureActorImage();
          createCircleOverlay();
        });
      } else {
        createCircleOverlay();
      }

      upperCanvas.style.display = 'block!important';
    } else {
      let zoomControls = document.querySelector('#zoom-controls');
      featuredControls.style.display = 'flex';
      mainCanvasElement.style.display = 'block';
      actorCanvasElement.style.display = 'none';
      mainCanvasContainer.style.display = 'block';
      actorCanvasContainer.style.display = 'none';
      actorCanvasElement.style.borderRadius = '';
      zoomControls.style.display = '';


      pageHeader.innerHTML = 'Featured Image Creator';

      const mainUpperCanvas = canvas.upperCanvasEl;
      if (mainUpperCanvas) {
        mainUpperCanvas.style.display = 'block';
      }

      // reset the main canvas dimensions
      canvas.setDimensions({
        width: 1200,
        height: 600
      });


      // restore the main image if it exists
      if (mainImage) {
        canvas.clear();
        canvas.add(mainImage);
        customRender();
      }
      actorImageObject = null;
      actorCanvas.clear();

      actorCanvas.getObjects().forEach(obj => {
        if (obj === circleOverlay) {
          actorCanvas.remove(obj);
          circleOverlay = null;
        }
      });
      actorCanvas.renderAll();
    }
  });

  function configureActorImage() {
    if (actorImageObject) {
      // Reset any existing cropping
      actorImageObject.set({
        cropX: 0,
        cropY: 0,
        width: actorImageObject.originalSize.width,
        height: actorImageObject.originalSize.height,
        scaleX: 1,
        scaleY: 1
      });

      const originalWidth = actorImageObject.width;
      const originalHeight = actorImageObject.height;

      let scale = Math.min(150 / originalWidth, 150 / originalHeight);

      actorImageObject.scaleToWidth(originalWidth * scale);
      actorImageObject.scaleToHeight(originalHeight * scale);

      // center image
      actorImageObject.set({
        left: (160 - actorImageObject.getScaledWidth()) / 2,
        top: (160 - actorImageObject.getScaledHeight()) / 2,
        selectable: true,
        hasControls: true,
        hasBorders: true,
        lockMovementX: false,
        lockMovementY: false,

        originX: 'left',
        originY: 'top'

      });

      actorImageObject.setControlsVisibility({
        tl: true, tr: true, bl: true, br: true,
        ml: false, mt: false, mr: false, mb: false,
        mtr: true
      });

      actorCanvas.clear();
      actorCanvas.add(actorImageObject);
      actorCanvas.renderAll();
    }
  }

  // modified image upload handler
  document.getElementById('image').addEventListener('change', function (e) {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onload = function (event) {
      fabric.Image.fromURL(event.target.result, (img) => {
        img.originalSize = { width: img.width, height: img.height }; // Store original size
        if (isActorImage) {
          actorImageObject = img;
          configureActorImage();
          if (circleOverlay && !actorCanvas.contains(circleOverlay)) {
            actorCanvas.add(circleOverlay);
          }
          renderActorCanvasWithOverlayOnTop();
        } else {
          mainImage = img;
          mainImageOptions(mainImage);
          customRender();
        }
        document.getElementById('resize').style.display = isActorImage ? 'none' : 'inline-block';
      });
    };
    reader.readAsDataURL(file);
  });

  actorCanvas.on('object:modified', function (e) {
    renderActorCanvasWithOverlayOnTop();
  });

  actorCanvas.on('object:moving', function (e) {
    renderActorCanvasWithOverlayOnTop();
  });

  actorCanvas.on('object:scaling', function (e) {
    renderActorCanvasWithOverlayOnTop();
  });

  actorCanvas.on('object:rotating', function (e) {
    renderActorCanvasWithOverlayOnTop();
  });

  // create bg rectangle function
  function createBackground() {
    if (mainImage) {
      // remove existing bg if any
      if (backgroundRect) {
        canvas.remove(backgroundRect);
      }

      // create new bg
      backgroundRect = new fabric.Rect({
        left: mainImage.left || 0,
        top: mainImage.top || 0,
        width: mainImage.width * (mainImage.scaleX || 1),
        height: mainImage.height * (mainImage.scaleY || 1),
        fill: 'white',
        selectable: false,
        evented: false
      });
    }
  }

  // main image options
  function mainImageOptions(object) {
    object.set({
      selectable: true,
      hasControls: true,
      hasBorders: true,
      lockMovementX: false,
      lockMovementY: false,
    });
    object.setControlsVisibility({
      tl: true, tr: true, bl: true, br: true,
      ml: false, mt: false, mr: false, mb: false,
      mtr: false
    });
  }

  function moveToTop(obj) {
    if (obj && obj !== mainImage) {
      obj.moveTo(canvas.getObjects().length - 1);
    }
  }

  // to ensure correct stacking order for the main canvas
  function customRender() {
    canvas.clear();
    createBackground();
    if (backgroundRect) canvas.add(backgroundRect);
    if (mainImage) canvas.add(mainImage);
    if (overlayImage) canvas.add(overlayImage);
    if (logoImage) canvas.add(logoImage);
    if (featherMask) canvas.add(featherMask);
    textBoxes.forEach(text => canvas.add(text));
    canvas.renderAll();
  }

  // image moving on main canvas
  canvas.on('object:modified', function (e) {
    if (e.target === mainImage) {
      moveToTop(overlayImage);
      customRender();
    }
  });

  // select text boxes on main canvas
  canvas.on('object:selected', function (e) {
    const selectedObject = e.target;
    if (selectedObject.type === 'i-text') {
      moveToTop(selectedObject);
    } else if (selectedObject === overlayImage) {
      moveToTop(overlayImage);
    }
  });

  function addTextBox(txt, left, top, fontSize, fontFamily, fill, bold) {
    const maxWidth = 225; // max width for text wrapping
    const lineHeight = 1.2; // line height factor

    const textLines = [];
    const words = txt.split(' ');
    let currentLine = '';

    words.forEach(word => {
      const testLine = currentLine.length > 0 ? currentLine + ' ' + word : word;
      const width = canvas.getContext().measureText(testLine).width;

      if (width < maxWidth) {
        currentLine = testLine;
      } else {
        textLines.push(currentLine);
        currentLine = word;
      }
    });

    textLines.push(currentLine);

    const text = new fabric.Textbox(textLines.join('\n'), {
      left: left,
      top: top,
      fontSize: fontSize,
      fontFamily: fontFamily,
      fill: fill,
      lineHeight: lineHeight,
      width: maxWidth,
      lockScalingX: false,
      fontWeight: bold ? 'bold' : 'normal',
    });

    moveToTop(text);
    textBoxes.push(text);

    customRender();
  }

  // change text color
  document.getElementById('text-color').addEventListener('change', function (e) {
    const selectedColor = e.target.value;
    const activeObject = canvas.getActiveObject();
    if (activeObject && (activeObject.type === 'i-text' || activeObject.type === 'textbox')) {
      activeObject.set('fill', selectedColor);
      canvas.renderAll();
    }
  });

  // change text boldness
  document.getElementById('weight').addEventListener('change', function (e) {
    const bold = e.target.checked;
    const activeObject = canvas.getActiveObject();
    if (activeObject && (activeObject.type === 'i-text' || activeObject.type === 'textbox')) {
      activeObject.set('fontWeight', bold ? 'bold' : 'normal');
      canvas.renderAll();
    }
  });

  // remove box on main canvas
  document.getElementById('remove').addEventListener('click', function () {
    const activeObject = canvas.getActiveObject();
    if (activeObject && (activeObject.type === 'i-text' || activeObject.type === 'textbox')) {
      canvas.remove(activeObject);
      const index = textBoxes.indexOf(activeObject);
      if (index !== -1) {
        textBoxes.splice(index, 1);
      }
      customRender();
    }
  });

  // toggle showing the prefilled text options div when the "Text" button is clicked
  document.getElementById('add').addEventListener('click', () => {
    document.getElementById('add').classList.toggle("text-options-active");
    document.getElementById('prefilled-text-options').classList.toggle('show');
  });

  // text options (prefilled)
  const textOptionButtons = document.querySelectorAll('.text-option');
  textOptionButtons.forEach(button => {
    button.addEventListener('click', function () {
      const selectedText = this.getAttribute('data-text');
      addTextBox(selectedText, 935, 525, 32, 'arial', '#000000', false);
      document.getElementById('prefilled-text-options').classList.toggle('show');
    });
  });

  // custom text selection
  document.getElementById('custom-text-option').addEventListener('click', () => {
    let customInputHeader = document.querySelector('.custom-header');

    const customInput = document.getElementById('custom-text-input');
    customInput.style.display = 'block';
    customInputHeader.style.display = 'block';
    customInput.focus();

    customInput.addEventListener('keyup', function (e) {
      if (e.key === 'Enter') {
        const customText = customInput.value;
        if (customText) {
          addTextBox(customText, 935, 525, 32, 'arial', '#000000', false);
          document.getElementById('prefilled-text-options').classList.toggle('show');
          customInput.style.display = 'none';
          customInput.value = '';
          customInputHeader.style.display = 'none';
        }
      }
    });
  });

  // resize image button (for main image)
  document.getElementById('resize').addEventListener('click', function () {
    if (mainImage) {
      mainImage.scaleToWidth(1210);
      createBackground();
      customRender();
    }
  });

  //  zoom controls for actor image
  document.getElementById('zoom-in').addEventListener('click', function () {
    if (isActorImage && actorImageObject) {
      // increase scale by 10%
      actorImageObject.set({
        scaleX: actorImageObject.scaleX * 1.1,
        scaleY: actorImageObject.scaleY * 1.1
      });
      actorCanvas.renderAll();
    }
  });

  document.getElementById('zoom-out').addEventListener('click', function () {
    if (isActorImage && actorImageObject) {
      // decrease scale by 10%
      actorImageObject.set({
        scaleX: actorImageObject.scaleX * 0.9,
        scaleY: actorImageObject.scaleY * 0.9
      });
      actorCanvas.renderAll();
    }
  });

  document.getElementById('zoom-reset').addEventListener('click', function () {
    if (isActorImage && actorImageObject) {
      // reset scale to original
      const originalWidth = actorImageObject.originalSize.width;
      const originalHeight = actorImageObject.originalSize.height;
      let scale = Math.min(150 / originalWidth, 150 / originalHeight);
      actorImageObject.set({
        scaleX: scale,
        scaleY: scale,
        left: (160 - originalWidth * scale) / 2,
        top: (160 - originalHeight * scale) / 2
      });
      actorCanvas.renderAll();
    }
  });

  // crop functionality for actor image
  document.getElementById('crop-actor').addEventListener('click', function () {
    if (!actorImageObject) return;

    isActorCropping = !isActorCropping;
    this.textContent = isActorCropping ? 'Cancel Crop' : 'Crop';
    document.getElementById('apply-crop-actor').style.display = isActorCropping ? 'inline-block' : 'none';

    if (isActorCropping) {
      // Disable other interactions
      actorImageObject.set({
        selectable: false,
        hasControls: false,
        hasBorders: false
      });
      actorCanvas.selection = false; // Disable canvas selection

      // Initialize the cropping rectangle
      cropRect = new fabric.Rect({
        left: actorImageObject.left,
        top: actorImageObject.top,
        width: actorImageObject.width * actorImageObject.scaleX,
        height: actorImageObject.height * actorImageObject.scaleY,
        fill: 'transparent',
        stroke: 'rgba(0,0,0,0.5)',
        strokeWidth: 1,
        cornerSize: 7,
        transparentCorners: false,
        controls: fabric.Object.prototype.controls, // Add default controls
        originX: 'left',
        originY: 'top'
      });
      actorCanvas.add(cropRect);
      actorCanvas.setActiveObject(cropRect);
      actorCanvas.renderAll();

    } else {
      // Re-enable interactions
      actorImageObject.set({
        selectable: true,
        hasControls: true,
        hasBorders: true
      });
      actorCanvas.selection = true;
      actorCanvas.remove(cropRect);
      cropRect = null;
      actorCanvas.renderAll();
    }
  });

  document.getElementById('apply-crop-actor').addEventListener('click', function () {
    if (!isActorCropping || !cropRect || !actorImageObject) return;

    const croppedX = cropRect.left - actorImageObject.left;
    const croppedY = cropRect.top - actorImageObject.top;
    const croppedWidth = cropRect.width;
    const croppedHeight = cropRect.height;

    const scaleX = actorImageObject.scaleX * (actorImageObject.width / croppedWidth);
    const scaleY = actorImageObject.scaleY * (actorImageObject.height / croppedHeight);

    actorImageObject.set({
      cropX: croppedX / actorImageObject.scaleX,
      cropY: croppedY / actorImageObject.scaleY,
      width: croppedWidth / actorImageObject.scaleX,
      height: croppedHeight / actorImageObject.scaleY,
      scaleX: scaleX,
      scaleY: scaleY,
      left: cropRect.left,
      top: cropRect.top
    });

    actorCanvas.remove(cropRect);
    cropRect = null;
    isActorCropping = false;
    document.getElementById('crop-actor').textContent = 'Crop';
    document.getElementById('apply-crop-actor').style.display = 'none';

    // Re-enable interactions
    actorImageObject.set({
      selectable: true,
      hasControls: true,
      hasBorders: true
    });
    actorCanvas.selection = true;
    actorCanvas.renderAll();
  });

  // feather mask
  let featherMask = null;

  document.getElementById('feather').addEventListener('change', function (e) {
    const featherOption = e.target.value;
    applyFeatherMask(featherOption);
  });

  function applyFeatherMask(option) {
    if (mainImage) {
      if (option !== 'none') {
        createFeatherMask(option);
      } else {
        removeFeatherMask();
      }
    }
  }

  function createFeatherMask(option) {
    const gradient = createGradient(option);
    featherMask = new fabric.Rect({
      left: 0,
      top: 0,
      // width: mainImage.width,
      // height: mainImage.height,
      width: canvas.width,
      height: canvas.height,
      fill: gradient,
      selectable: false,
      evented: false
    });
    canvas.add(featherMask);
    moveToTop(featherMask);
    customRender();
  }

  function createGradient(option) {
    const gradient = new fabric.Gradient({
      type: 'linear',
      coords: { x1: 0, y1: canvas.height, x2: 0, y2: canvas.height - 200 },
      colorStops: [
        { offset: 0, color: option === 'black' ? 'rgba(0,0,0,0.6)' : 'rgba(255,255,255,0.4)' },
        { offset: 1, color: option === 'black' ? 'rgba(0,0,0,0)' : 'rgba(255,255,255,0)' }
      ]
    });
    return gradient;
  }

  function removeFeatherMask() {
    if (featherMask) {
      canvas.remove(featherMask);
      mainImage.set('globalCompositeOperation', 'source-over');
      canvas.renderAll();
      featherMask = null;
    }
  }

  // save image
  document.getElementById('export').addEventListener('click', function () {
    const activeCanvas = isActorImage ? actorCanvas : canvas;
    activeCanvas.discardActiveObject();

    let exportOptions = {
      format: 'png',
      quality: 1,
      backgroundColor: 'white'
    };

    if (isActorImage) {
      const overlayToRemove = circleOverlay;
      if (overlayToRemove) {
        actorCanvas.remove(overlayToRemove);
      }
      actorCanvas.renderAll();

      const bgRect = new fabric.Rect({
        left: 0,
        top: 0,
        width: 160,
        height: 160,
        fill: 'white',
        selectable: false,
        evented: false
      });
      actorCanvas.insertAt(bgRect, 0, false);
      actorCanvas.renderAll();

      exportOptions.width = 160;
      exportOptions.height = 160;
    } else {
      exportOptions.width = 1200;
      exportOptions.height = 600;
    }

    const dataURL = activeCanvas.toDataURL(exportOptions);

    if (isActorImage) {
      actorCanvas.remove(actorCanvas.item(0));
      if (circleOverlay) {
        actorCanvas.add(circleOverlay);
        actorCanvas.moveTo(circleOverlay, actorCanvas.getObjects().length - 1);
        actorCanvas.renderAll();
      }
    }

    const link = document.createElement('a');
    link.href = dataURL;
    link.download = isActorImage ? 'actor-image.png' : 'featured-image.png';
    link.click();
  });


  // overlay selection for the main canvas
  document.getElementById('overlays').addEventListener('change', function (e) {
    const selectedOverlay = e.target.value;

    if (selectedOverlay !== 'default') {
      fabric.Image.fromURL(`/overlays/${selectedOverlay}`, (img) => {
        img.set({
          selectable: true,
          hasControls: true,
          hasBorders: true,
          lockMovementX: false,
          lockMovementY: false,
          originX: 'left',
          originY: 'top',
        });
        overlayImage = img;
        moveToTop(overlayImage);
        customRender();
      });
    } else {
      // remove any existing overlay
      if (overlayImage) {
        canvas.remove(overlayImage);
        overlayImage = null;
      }
      customRender();
    }
  });

  // logos for the main canvas
  document.getElementById('logos').addEventListener('change', function (e) {
    const selectedLogo = e.target.value;

    if (selectedLogo !== 'default') {
      fabric.Image.fromURL(`/logos/${selectedLogo}`, (img) => {
        img.set({
          selectable: true,
          hasControls: true,
          hasBorders: true,
          lockMovementX: false,
          lockMovementY: false,
          originX: 'right',
          originY: 'bottom',
          top: 570,
          left: 1170,
        });
        logoImage = img;
        moveToTop(logoImage);
        customRender();
      });
    } else {

      if (logoImage) {
        canvas.remove(logoImage);
        logoImage = null;
      }
      customRender();
    }
  });

  const textOptionsToggle = document.getElementById('text-options-toggle');
  const textOptionsMenu = document.getElementById('text-options-menu');

  textOptionsToggle.addEventListener('click', () => {
    textOptionsToggle.classList.toggle("active");
    textOptionsMenu.classList.toggle('show');
  });

  // alignments
  document.getElementById('align-left').addEventListener('click', function () {
    alignText('left');
  });

  document.getElementById('align-center').addEventListener('click', function () {
    alignText('center');
  });

  document.getElementById('align-right').addEventListener('click', function () {
    alignText('right');
  });

  function alignText(alignment) {
    const activeObject = canvas.getActiveObject();
    if (activeObject && (activeObject.type === 'i-text' || activeObject.type === 'textbox')) {
      activeObject.set('textAlign', alignment);
      canvas.renderAll();
    }
  }
});
