/*
#    ___  ___ ___  _______  _______  _______     _______  _______  _______  _______  _______  _______  _______
#   |   ||   Y   ||   _   ||   _   ||   _   |   |   _   ||   _   \|   _   ||   _   ||       ||   _   ||   _   \
#   |.  ||.      ||.  1   ||.  |___||.  1___|   |.  1___||.  l   /|.  1___||.  1   ||.|   | ||.  |   ||.  l   /
#   |.  ||. \_/  ||.  _   ||.  |   ||.  __)_    |.  |___ |.  _   1|.  __)_ |.  _   |`-|.  |-'|.  |   ||.  _   1
#   |:  ||:  |   ||:  |   ||:  1   ||:  1   |   |:  1   ||:  |   ||:  1   ||:  |   |  |:  |  |:  1   ||:  |   |
#   |::.||::.|:. ||::.|:. ||::.. . ||::.. . |   |::.. . ||::.|:. ||::.. . ||::.|:. |  |::.|  |::.. . ||::.|:. |
#   `---'`--- ---'`--- ---'`-------'`-------'   `-------'`--- ---'`-------'`--- ---'  `---'  `-------'`--- ---'
#   by vincent scotto (doxtilites.com)
*/

document.addEventListener("DOMContentLoaded", () => {
	const canvas = new fabric.Canvas("canvas");
	let mainImage;
	let overlayImage;
	let textBoxes = [];
	let logoImage = null;
	let backgroundRect = null;
	let circleOverlay;

	// remember original upload filenames so exports keep them
	let mainImageFilename = null;
	let actorImageFilename = null;

	// batch mode state
	let batchMode = false;
	let batchImages = [];
	let activeBatchIndex = -1;

	const fileInput = document.getElementById("image");
	const batchPanel = document.getElementById("batchPanel");
	const batchThumbnailsEl = document.getElementById("batchThumbnails");
	const batchCountEl = document.getElementById("batchCount");

	function uid(prefix) {
		return `${prefix}-${Date.now().toString(36)}-${Math.random()
			.toString(36)
			.slice(2, 7)}`;
	}

	// =========================================================================
	// notifications: toasts + confirm modal (no alert/confirm)
	// =========================================================================

	function ensureToastContainer() {
		let c = document.querySelector(".toast-container");
		if (c) return c;
		c = document.createElement("div");
		c.className = "toast-container";
		// inline fallback styles so it works pre-scss-recompile
		Object.assign(c.style, {
			position: "fixed",
			top: "20px",
			left: "50%",
			transform: "translateX(-50%)",
			zIndex: "9999",
			display: "flex",
			flexDirection: "column",
			gap: "10px",
			pointerEvents: "none"
		});
		document.body.appendChild(c);
		return c;
	}

	function showNotification(message, options = {}) {
		const { type = "info", duration } = options;
		const container = ensureToastContainer();
		const toast = document.createElement("div");
		toast.className = `toast toast-${type}`;

		const accent =
			type === "success"
				? "#22ad00"
				: type === "error"
				? "#db515a"
				: type === "warning"
				? "#ffcb00"
				: "#03a9f4";

		Object.assign(toast.style, {
			pointerEvents: "auto",
			minWidth: "300px",
			maxWidth: "520px",
			padding: "14px 18px",
			borderRadius: "8px",
			fontFamily: "Nunito, sans-serif",
			fontSize: "14px",
			fontWeight: "500",
			background: "#fff",
			color: "#2a2a2a",
			boxShadow: "0 8px 24px rgba(0,0,0,0.15)",
			borderLeft: `4px solid ${accent}`,
			display: "flex",
			alignItems: "center",
			gap: "12px",
			transition: "opacity 0.25s ease, transform 0.25s ease"
		});

		const msg = document.createElement("div");
		msg.className = "toast-message";
		msg.style.flex = "1";
		msg.style.lineHeight = "1.4";
		msg.textContent = message;

		const close = document.createElement("button");
		close.className = "toast-close";
		close.type = "button";
		close.setAttribute("aria-label", "Dismiss");
		close.textContent = "×";
		Object.assign(close.style, {
			width: "24px",
			height: "24px",
			padding: "0",
			background: "transparent",
			border: "none",
			color: "#999",
			fontSize: "18px",
			lineHeight: "1",
			cursor: "pointer",
			borderRadius: "50%",
			flexShrink: "0"
		});

		const dismiss = () => {
			toast.style.opacity = "0";
			toast.style.transform = "translateY(-12px)";
			setTimeout(() => toast.remove(), 250);
		};
		close.addEventListener("click", dismiss);

		toast.appendChild(msg);
		toast.appendChild(close);
		container.appendChild(toast);

		const ttl =
			duration != null ? duration : type === "error" ? 6000 : 3500;
		if (ttl > 0) setTimeout(dismiss, ttl);

		return { dismiss };
	}

	function showConfirm(message, options = {}) {
		const {
			title = "Are you sure?",
			confirmText = "Confirm",
			cancelText = "Cancel",
			tone = "danger"
		} = options;

		return new Promise((resolve) => {
			const backdrop = document.createElement("div");
			backdrop.className = "modal-backdrop";
			Object.assign(backdrop.style, {
				position: "fixed",
				inset: "0",
				background: "rgba(20,28,40,0.55)",
				display: "flex",
				alignItems: "center",
				justifyContent: "center",
				zIndex: "9998"
			});

			const card = document.createElement("div");
			card.className = "modal-card";
			Object.assign(card.style, {
				background: "#fff",
				borderRadius: "12px",
				padding: "26px 28px",
				minWidth: "340px",
				maxWidth: "480px",
				boxShadow: "0 24px 60px rgba(0,0,0,0.3)",
				textAlign: "center",
				fontFamily: "Nunito, sans-serif"
			});

			const titleEl = document.createElement("div");
			titleEl.className = "modal-title";
			Object.assign(titleEl.style, {
				fontSize: "18px",
				fontWeight: "700",
				marginBottom: "10px",
				color: "#1f1f1f"
			});
			titleEl.textContent = title;

			const msgEl = document.createElement("div");
			msgEl.className = "modal-message";
			Object.assign(msgEl.style, {
				fontSize: "14px",
				color: "#4a4a4a",
				marginBottom: "22px",
				lineHeight: "1.5"
			});
			msgEl.textContent = message;

			const actions = document.createElement("div");
			actions.className = "modal-actions";
			Object.assign(actions.style, {
				display: "flex",
				gap: "10px",
				justifyContent: "center"
			});

			const cancelBtn = document.createElement("button");
			cancelBtn.className = "modal-cancel";
			cancelBtn.type = "button";
			cancelBtn.textContent = cancelText;
			Object.assign(cancelBtn.style, {
				width: "auto",
				height: "auto",
				padding: "10px 22px",
				borderRadius: "6px",
				fontWeight: "600",
				cursor: "pointer",
				background: "#e3e6eb",
				color: "#333",
				border: "none"
			});

			const confirmBtn = document.createElement("button");
			confirmBtn.className =
				"modal-confirm" +
				(tone === "primary" ? " modal-confirm-primary" : "");
			confirmBtn.type = "button";
			confirmBtn.textContent = confirmText;
			Object.assign(confirmBtn.style, {
				width: "auto",
				height: "auto",
				padding: "10px 22px",
				borderRadius: "6px",
				fontWeight: "600",
				cursor: "pointer",
				background: tone === "primary" ? "#22ad00" : "#db515a",
				color: "#fff",
				border: "none"
			});

			const cleanup = (result) => {
				backdrop.remove();
				document.removeEventListener("keydown", onKey);
				resolve(result);
			};
			const onKey = (e) => {
				if (e.key === "Escape") cleanup(false);
				if (e.key === "Enter") cleanup(true);
			};

			cancelBtn.addEventListener("click", () => cleanup(false));
			confirmBtn.addEventListener("click", () => cleanup(true));
			backdrop.addEventListener("click", (e) => {
				if (e.target === backdrop) cleanup(false);
			});
			document.addEventListener("keydown", onKey);

			actions.appendChild(cancelBtn);
			actions.appendChild(confirmBtn);
			card.appendChild(titleEl);
			card.appendChild(msgEl);
			card.appendChild(actions);
			backdrop.appendChild(card);
			document.body.appendChild(backdrop);
			confirmBtn.focus();
		});
	}

	function sanitizeBaseName(name) {
		if (!name) return "image";
		return name.replace(/\.[^.]+$/, "").replace(/[\\/:*?"<>|]+/g, "_");
	}

	const actorCanvas = new fabric.Canvas("actorCanvas", {
		backgroundColor: "white"
	});
	let isActorImage = false;
	let actorImageObject = null;

	const featuredControls = document.getElementById("featuredImageControls");
	const mainCanvasElement = document.getElementById("canvas");
	const actorCanvasElement = document.getElementById("actorCanvas");
	const mainCanvasContainer = document.querySelector(
		".canvas-container:first-of-type"
	);
	const actorCanvasContainer = document.querySelector(
		".canvas-container:last-of-type"
	);
	const pageHeader = document.querySelector("h2.page-header");

	const renderActorCanvasWithOverlayOnTop = () => {
		if (isActorImage && circleOverlay) {
			actorCanvas.discardActiveObject();
			const objects = actorCanvas
				.getObjects()
				.filter((obj) => obj !== circleOverlay);
			actorCanvas.clear();
			actorCanvas.add(...objects, circleOverlay);
			actorCanvas.renderAll();
		}
	};

	// actor image checkbox
	document
		.getElementById("isActorImage")
		.addEventListener("change", function (e) {
			isActorImage = e.target.checked;
			console.log("isActorImage:", isActorImage);

			if (isActorImage) {
				let upperCanvas = document.querySelector(".upper-canvas");
				let zoomControls = document.querySelector("#zoom-controls");

				featuredControls.style.display = "none";
				mainCanvasElement.style.display = "none";
				actorCanvasElement.style.display = "block";
				mainCanvasContainer.style.display = "none";
				actorCanvasContainer.style.display = "block";
				zoomControls.style.display = "flex";

				pageHeader.innerHTML = "Actor Image";

				const actorUpperCanvas = actorCanvas.upperCanvasEl;
				if (actorUpperCanvas) {
					actorUpperCanvas.style.display = "block";
					actorUpperCanvas.style.top = "20px";
				}

				actorCanvas.setDimensions({
					width: 160,
					height: 160
				});

				const createCircleOverlay = () => {
					circleOverlay = new fabric.Circle({
						radius: 80,
						left: actorCanvas.width / 2,
						top: actorCanvas.height / 2,
						originX: "center",
						originY: "center",
						fill: "rgba(0, 0, 0, 0.3)",
						selectable: false,
						evented: false
					});
					actorCanvas.add(circleOverlay);
					renderActorCanvasWithOverlayOnTop();
				};

				if (mainImage) {
					const img = mainImage.getElement();
					fabric.Image.fromURL(img.src, (loadedImg) => {
						actorImageObject = loadedImg;
						configureActorImage();
						createCircleOverlay();
					});
				} else {
					createCircleOverlay();
				}

				upperCanvas.style.display = "block!important";
			} else {
				let zoomControls = document.querySelector("#zoom-controls");
				featuredControls.style.display = "flex";
				mainCanvasElement.style.display = "block";
				actorCanvasElement.style.display = "none";
				mainCanvasContainer.style.display = "block";
				actorCanvasContainer.style.display = "none";
				actorCanvasElement.style.borderRadius = "";
				zoomControls.style.display = "";

				pageHeader.innerHTML = "Featured Image Creator";

				const mainUpperCanvas = canvas.upperCanvasEl;
				if (mainUpperCanvas) {
					mainUpperCanvas.style.display = "block";
				}

				// reset the main canvas dimensions
				canvas.setDimensions({
					width: 1200,
					height: 600
				});

				// restore the main image if it exists
				if (mainImage) {
					canvas.clear();
					canvas.add(mainImage);
					customRender();
				}
				actorImageObject = null;
				actorCanvas.clear();

				actorCanvas.getObjects().forEach((obj) => {
					if (obj === circleOverlay) {
						actorCanvas.remove(obj);
						circleOverlay = null;
					}
				});
				actorCanvas.renderAll();
			}
		});

	function configureActorImage() {
		if (actorImageObject) {
			// calc scale to fit the image entirely within the 160x160 canvas. ensures the whole image is visible initially.
			const scaleX = actorCanvas.width / actorImageObject.width;
			const scaleY = actorCanvas.height / actorImageObject.height;
			const scale = Math.min(scaleX, scaleY);

			actorImageObject.set({
				scaleX: scale,
				scaleY: scale,
				// center image within the 160x160 canvas
				left: (actorCanvas.width - actorImageObject.width * scale) / 2,
				top: (actorCanvas.height - actorImageObject.height * scale) / 2,
				selectable: true,
				hasControls: true,
				hasBorders: true,
				lockMovementX: false,
				lockMovementY: false,
				originX: "left",
				originY: "top"
			});

			actorImageObject.setControlsVisibility({
				tl: true,
				tr: true,
				bl: true,
				br: true,
				ml: false,
				mt: false,
				mr: false,
				mb: false,
				mtr: true
			});

			actorCanvas.clear();
			actorCanvas.add(actorImageObject);
			actorCanvas.renderAll();
		}
	}

	// modified image upload handler
	document.getElementById("image").addEventListener("change", function (e) {
		const files = Array.from(e.target.files || []);
		if (files.length === 0) return;

		if (batchMode) {
			handleBatchUpload(files);
			return;
		}

		const file = files[0];
		const reader = new FileReader();

		reader.onload = function (event) {
			fabric.Image.fromURL(event.target.result, (img) => {
				if (isActorImage) {
					actorImageObject = img;
					actorImageFilename = file.name;
					configureActorImage();
					if (circleOverlay && !actorCanvas.contains(circleOverlay)) {
						actorCanvas.add(circleOverlay);
					}
					renderActorCanvasWithOverlayOnTop();
				} else {
					mainImage = img;
					mainImageFilename = file.name;
					mainImageOptions(mainImage);
					customRender();
				}
				document.getElementById("resize").style.display = isActorImage
					? "none"
					: "inline-block";
			});
		};
		reader.readAsDataURL(file);
	});

	actorCanvas.on("object:modified", function (e) {
		renderActorCanvasWithOverlayOnTop();
	});

	actorCanvas.on("object:moving", function (e) {
		renderActorCanvasWithOverlayOnTop();
	});

	actorCanvas.on("object:scaling", function (e) {
		renderActorCanvasWithOverlayOnTop();
	});

	actorCanvas.on("object:rotating", function (e) {
		renderActorCanvasWithOverlayOnTop();
	});

	// create bg rectangle function
	function createBackground() {
		if (mainImage) {
			// remove existing bg if any
			if (backgroundRect) {
				canvas.remove(backgroundRect);
			}

			// create new bg
			backgroundRect = new fabric.Rect({
				left: mainImage.left || 0,
				top: mainImage.top || 0,
				width: mainImage.width * (mainImage.scaleX || 1),
				height: mainImage.height * (mainImage.scaleY || 1),
				fill: "white",
				selectable: false,
				evented: false
			});
		}
	}

	// main image options
	function mainImageOptions(object) {
		object.set({
			selectable: true,
			hasControls: true,
			hasBorders: true,
			lockMovementX: false,
			lockMovementY: false
		});
		object.setControlsVisibility({
			tl: true,
			tr: true,
			bl: true,
			br: true,
			ml: false,
			mt: false,
			mr: false,
			mb: false,
			mtr: false
		});
	}

	function moveToTop(obj) {
		if (obj && obj !== mainImage) {
			obj.moveTo(canvas.getObjects().length - 1);
		}
	}

	// to ensure correct stacking order for the main canvas
	function customRender() {
		canvas.clear();
		createBackground();
		if (backgroundRect) canvas.add(backgroundRect);
		if (mainImage) canvas.add(mainImage);
		if (overlayImage) canvas.add(overlayImage);
		if (logoImage) canvas.add(logoImage);
		if (featherMask) canvas.add(featherMask);
		textBoxes.forEach((text) => canvas.add(text));
		canvas.renderAll();
	}

	// image moving on main canvas
	canvas.on("object:modified", function (e) {
		if (e.target === mainImage) {
			moveToTop(overlayImage);
			customRender();
		}
	});

	// select text boxes on main canvas
	canvas.on("object:selected", function (e) {
		const selectedObject = e.target;
		if (selectedObject.type === "i-text") {
			moveToTop(selectedObject);
		} else if (selectedObject === overlayImage) {
			moveToTop(overlayImage);
		}
	});

	function buildTextbox(txt, left, top, fontSize, fontFamily, fill, bold, batchId) {
		const maxWidth = 225; // max width for text wrapping
		const lineHeight = 1.2; // line height factor

		const textLines = [];
		const words = txt.split(" ");
		let currentLine = "";

		words.forEach((word) => {
			const testLine = currentLine.length > 0 ? currentLine + " " + word : word;
			const width = canvas.getContext().measureText(testLine).width;

			if (width < maxWidth) {
				currentLine = testLine;
			} else {
				textLines.push(currentLine);
				currentLine = word;
			}
		});

		textLines.push(currentLine);

		const text = new fabric.Textbox(textLines.join("\n"), {
			left: left,
			top: top,
			fontSize: fontSize,
			fontFamily: fontFamily,
			fill: fill,
			lineHeight: lineHeight,
			width: maxWidth,
			lockScalingX: false,
			fontWeight: bold ? "bold" : "normal"
		});

		if (batchId) text._batchId = batchId;
		return text;
	}

	function addTextBox(txt, left, top, fontSize, fontFamily, fill, bold) {
		const batchId = batchMode ? uid("text") : null;
		const text = buildTextbox(
			txt,
			left,
			top,
			fontSize,
			fontFamily,
			fill,
			bold,
			batchId
		);
		moveToTop(text);
		textBoxes.push(text);
		customRender();
		if (batchMode) refreshActiveThumbnail();
	}

	// change text color
	document
		.getElementById("text-color")
		.addEventListener("change", function (e) {
			const selectedColor = e.target.value;
			const activeObject = canvas.getActiveObject();
			if (
				activeObject &&
				(activeObject.type === "i-text" || activeObject.type === "textbox")
			) {
				activeObject.set("fill", selectedColor);
				canvas.renderAll();
			}
		});

	// change text boldness
	document.getElementById("weight").addEventListener("change", function (e) {
		const bold = e.target.checked;
		const activeObject = canvas.getActiveObject();
		if (
			activeObject &&
			(activeObject.type === "i-text" || activeObject.type === "textbox")
		) {
			activeObject.set("fontWeight", bold ? "bold" : "normal");
			canvas.renderAll();
		}
	});

	// remove box on main canvas (per-image only; use Apply to All to broadcast)
	document.getElementById("remove").addEventListener("click", function () {
		const activeObject = canvas.getActiveObject();
		if (
			activeObject &&
			(activeObject.type === "i-text" || activeObject.type === "textbox")
		) {
			canvas.remove(activeObject);
			const index = textBoxes.indexOf(activeObject);
			if (index !== -1) textBoxes.splice(index, 1);
			customRender();
			if (batchMode) refreshActiveThumbnail();
		}
	});

	// toggle showing the prefilled text options div when the "text" button is clicked
	document.getElementById("add").addEventListener("click", () => {
		document.getElementById("add").classList.toggle("text-options-active");
		document.getElementById("prefilled-text-options").classList.toggle("show");
	});

	// text options (prefilled)
	const textOptionButtons = document.querySelectorAll(".text-option");
	textOptionButtons.forEach((button) => {
		button.addEventListener("click", function () {
			const selectedText = this.getAttribute("data-text");
			addTextBox(selectedText, 935, 525, 32, "arial", "#000000", false);
			document
				.getElementById("prefilled-text-options")
				.classList.toggle("show");
		});
	});

	// custom text selection
	document
		.getElementById("custom-text-option")
		.addEventListener("click", () => {
			let customInputHeader = document.querySelector(".custom-header");

			const customInput = document.getElementById("custom-text-input");
			customInput.style.display = "block";
			customInputHeader.style.display = "block";
			customInput.focus();

			customInput.addEventListener("keyup", function (e) {
				if (e.key === "Enter") {
					const customText = customInput.value;
					if (customText) {
						addTextBox(customText, 935, 525, 32, "arial", "#000000", false);
						document
							.getElementById("prefilled-text-options")
							.classList.toggle("show");
						customInput.style.display = "none";
						customInput.value = "";
						customInputHeader.style.display = "none";
					}
				}
			});
		});

	// resize image button (for main image)
	document.getElementById("resize").addEventListener("click", function () {
		if (batchMode && batchImages.length > 0) {
			batchImages.forEach((state) => {
				if (state.mainImage) state.mainImage.scaleToWidth(1210);
			});
			customRender();
			renderThumbnails();
			return;
		}
		if (mainImage) {
			mainImage.scaleToWidth(1210);
			createBackground();
			customRender();
		}
	});

	//  zoom controls for actor image
	document.getElementById("zoom-in").addEventListener("click", function () {
		if (isActorImage && actorImageObject) {
			// increase scale by 10%
			actorImageObject.set({
				scaleX: actorImageObject.scaleX * 1.1,
				scaleY: actorImageObject.scaleY * 1.1
			});
			actorCanvas.renderAll();
		}
	});

	document.getElementById("zoom-out").addEventListener("click", function () {
		if (isActorImage && actorImageObject) {
			// decrease scale by 10%
			actorImageObject.set({
				scaleX: actorImageObject.scaleX * 0.9,
				scaleY: actorImageObject.scaleY * 0.9
			});
			actorCanvas.renderAll();
		}
	});

	document.getElementById("zoom-reset").addEventListener("click", function () {
		if (isActorImage && actorImageObject) {
			// reset the image to its initial fit-to-canvas state
			configureActorImage();
		}
	});

	// feather mask
	let featherMask = null;

	document.getElementById("feather").addEventListener("change", function (e) {
		const featherOption = e.target.value;
		if (batchMode && batchImages.length > 0) {
			const state = batchImages[activeBatchIndex];
			state.feather = featherOption;
			state.featherMask =
				featherOption === "none" ? null : buildFeatherMask(featherOption);
			featherMask = state.featherMask;
			customRender();
			refreshActiveThumbnail();
			return;
		}
		applyFeatherMask(featherOption);
	});

	function buildFeatherMask(option) {
		const gradient = createGradient(option);
		return new fabric.Rect({
			left: 0,
			top: 0,
			width: canvas.width,
			height: canvas.height,
			fill: gradient,
			selectable: false,
			evented: false
		});
	}

	function applyFeatherMask(option) {
		if (mainImage) {
			if (option !== "none") {
				createFeatherMask(option);
			} else {
				removeFeatherMask();
			}
		}
	}

	function createFeatherMask(option) {
		const gradient = createGradient(option);
		featherMask = new fabric.Rect({
			left: 0,
			top: 0,
			width: canvas.width,
			height: canvas.height,
			fill: gradient,
			selectable: false,
			evented: false
		});
		canvas.add(featherMask);
		moveToTop(featherMask);
		customRender();
	}

	function createGradient(option) {
		const gradient = new fabric.Gradient({
			type: "linear",
			coords: { x1: 0, y1: canvas.height, x2: 0, y2: canvas.height - 200 },
			colorStops: [
				{
					offset: 0,
					color:
						option === "black" ? "rgba(0,0,0,0.6)" : "rgba(255,255,255,0.4)"
				},
				{
					offset: 1,
					color: option === "black" ? "rgba(0,0,0,0)" : "rgba(255,255,255,0)"
				}
			]
		});
		return gradient;
	}

	function removeFeatherMask() {
		if (featherMask) {
			canvas.remove(featherMask);
			mainImage.set("globalCompositeOperation", "source-over");
			canvas.renderAll();
			featherMask = null;
		}
	}

	// save image
	document.getElementById("export").addEventListener("click", function () {
		const activeCanvas = isActorImage ? actorCanvas : canvas;
		activeCanvas.discardActiveObject();

		let exportOptions = {
			format: "png",
			quality: 1, // maximum quality!#%
			backgroundColor: "white"
		};

		if (isActorImage) {
			const overlayToRemove = circleOverlay;
			if (overlayToRemove) {
				actorCanvas.remove(overlayToRemove);
			}
			actorCanvas.renderAll();

			const bgRect = new fabric.Rect({
				left: 0,
				top: 0,
				width: 160,
				height: 160,
				fill: "white",
				selectable: false,
				evented: false
			});
			actorCanvas.insertAt(bgRect, 0, false);
			actorCanvas.renderAll();

			// render at a higher resolution and then scale down.
			exportOptions.multiplier = 2;
			exportOptions.width = 160;
			exportOptions.height = 160;
		} else {
			exportOptions.width = 1200;
			exportOptions.height = 600;
		}

		const dataURL = activeCanvas.toDataURL(exportOptions);

		if (isActorImage) {
			// re-add background and overlay after export for continued editing
			actorCanvas.remove(actorCanvas.item(0)); // remove the temporary background
			if (circleOverlay) {
				actorCanvas.add(circleOverlay);
				actorCanvas.moveTo(circleOverlay, actorCanvas.getObjects().length - 1);
				actorCanvas.renderAll();
			}
		}

		const link = document.createElement("a");
		link.href = dataURL;
		const sourceName = isActorImage ? actorImageFilename : mainImageFilename;
		const baseName = sanitizeBaseName(
			sourceName || (isActorImage ? "actor-image" : "featured-image")
		);
		link.download = `${baseName}.png`;
		link.click();
	});

	// psd export functionality
	document
		.getElementById("export-psd")
		.addEventListener("click", async function () {
			const activeCanvas = isActorImage ? actorCanvas : canvas;
			activeCanvas.discardActiveObject();

			// show loading state
			const exportButton = document.getElementById("export-psd");
			const originalText = exportButton.textContent;
			exportButton.textContent = "Generating PSD...";
			exportButton.disabled = true;

			try {
				// create psd
				const psd = {
					width: isActorImage ? 160 : 1200,
					height: isActorImage ? 160 : 600,
					children: []
				};

				// get all objects from the canvas
				const objects = activeCanvas.getObjects();

				// process each object and add to psd layers
				for (let i = 0; i < objects.length; i++) {
					const obj = objects[i];

					// skip circle overlay for actor images as it's just a visual guide
					if (isActorImage && obj === circleOverlay) {
						continue;
					}

					if (obj.type === "image") {
						// handle image objects (main image, overlays, logos)
						const imgElement = obj.getElement();

						// check if the image element is valid
						if (
							!imgElement ||
							!imgElement.complete ||
							imgElement.naturalWidth === 0
						) {
							console.warn("Invalid image element for object:", obj);
							continue;
						}

						const tempCanvas = document.createElement("canvas");
						const ctx = tempCanvas.getContext("2d");

						// use the actual image dimensions or scaled dimensions
						const imgWidth = imgElement.naturalWidth || imgElement.width;
						const imgHeight = imgElement.naturalHeight || imgElement.height;

						tempCanvas.width = obj.width * obj.scaleX;
						tempCanvas.height = obj.height * obj.scaleY;

						// clear the canvas first
						ctx.clearRect(0, 0, tempCanvas.width, tempCanvas.height);

						// try to draw the image
						try {
							ctx.drawImage(
								imgElement,
								0,
								0,
								imgWidth,
								imgHeight,
								0,
								0,
								tempCanvas.width,
								tempCanvas.height
							);

							// check if the canvas has any data
							const imageData = ctx.getImageData(
								0,
								0,
								tempCanvas.width,
								tempCanvas.height
							);
							const hasData = imageData.data.some((pixel) => pixel !== 0);

							if (!hasData) {
								console.warn("Canvas is empty after drawing image:", obj);
								if (obj === logoImage) {
									console.warn(
										"Logo canvas is empty - this might be the issue!"
									);
								}
							} else {
								if (obj === logoImage) {
									console.log("Logo canvas has data - drawing successful");
								}
							}
						} catch (error) {
							console.error("Error drawing image to canvas:", error);
							continue;
						}

						// determine layer name based on object properties
						let layerName = "Image Layer";
						if (obj === mainImage) {
							layerName = "Main Image";
						} else if (obj === overlayImage) {
							layerName = "Banner Overlay";
							console.log("Processing overlay:", {
								width: tempCanvas.width,
								height: tempCanvas.height,
								imgWidth: imgWidth,
								imgHeight: imgHeight,
								objWidth: obj.width,
								objHeight: obj.height,
								scaleX: obj.scaleX,
								scaleY: obj.scaleY,
								left: obj.left,
								top: obj.top,
								originX: obj.originX,
								originY: obj.originY
							});
						} else if (obj === logoImage) {
							layerName = "Logo";
							console.log("Processing logo:", {
								width: tempCanvas.width,
								height: tempCanvas.height,
								imgWidth: imgWidth,
								imgHeight: imgHeight,
								objWidth: obj.width,
								objHeight: obj.height,
								scaleX: obj.scaleX,
								scaleY: obj.scaleY,
								left: obj.left,
								top: obj.top,
								originX: obj.originX,
								originY: obj.originY
							});
						} else if (obj === actorImageObject) {
							layerName = "Actor Image";
						}

						// calculate correct position based on origin point
						let adjustedLeft = obj.left;
						let adjustedTop = obj.top;

						// adjust position for different origin points
						if (obj.originX === "right") {
							adjustedLeft = obj.left - obj.width * obj.scaleX;
						} else if (obj.originX === "center") {
							adjustedLeft = obj.left - (obj.width * obj.scaleX) / 2;
						}

						if (obj.originY === "bottom") {
							adjustedTop = obj.top - obj.height * obj.scaleY;
						} else if (obj.originY === "center") {
							adjustedTop = obj.top - (obj.height * obj.scaleY) / 2;
						}

						// debug position adjustments for logos
						if (obj === logoImage) {
							console.log("Logo position adjustment:", {
								originalLeft: obj.left,
								originalTop: obj.top,
								adjustedLeft: adjustedLeft,
								adjustedTop: adjustedTop,
								originX: obj.originX,
								originY: obj.originY
							});
						}

						psd.children.push({
							name: layerName,
							left: adjustedLeft,
							top: adjustedTop,
							canvas: tempCanvas,
							opacity: obj.opacity || 1,
							blendMode: "normal"
						});
					} else if (obj.type === "i-text" || obj.type === "textbox") {
						// handle text objects - create as text layer for better editing
						const textCanvas = document.createElement("canvas");
						const textCtx = textCanvas.getContext("2d");

						// set text properties
						textCtx.font = `${obj.fontWeight === "bold" ? "bold " : ""}${
							obj.fontSize
						}px ${obj.fontFamily}`;
						textCtx.fillStyle = obj.fill;
						textCtx.textAlign = obj.textAlign || "left";

						// measure text
						const metrics = textCtx.measureText(obj.text);
						const textWidth = metrics.width;
						const textHeight = obj.fontSize;

						textCanvas.width = textWidth;
						textCanvas.height = textHeight;

						// redraw text on the new canvas
						textCtx.font = `${obj.fontWeight === "bold" ? "bold " : ""}${
							obj.fontSize
						}px ${obj.fontFamily}`;
						textCtx.fillStyle = obj.fill;
						textCtx.textAlign = obj.textAlign || "left";
						textCtx.fillText(obj.text, 0, textHeight * 0.8); // adjust baseline

						// create text layer with both canvas and text data
						const textLayer = {
							name: `Text: ${obj.text}`,
							left: obj.left,
							top: obj.top,
							canvas: textCanvas,
							opacity: obj.opacity || 1,
							blendMode: "normal",
							text: {
								text: obj.text,
								transform: [1, 0, 0, 1, obj.left, obj.top + obj.fontSize * 0.8], // adjust baseline for better positioning
								style: {
									font: { name: getFullFontName(obj.fontFamily) },
									fontSize: obj.fontSize,
									fillColor: parseColor(obj.fill)
								}
							}
						};

						psd.children.push(textLayer);
					} else if (obj.type === "rect") {
						// handle rectangle objects (backgrounds, feather masks, etc.)
						const rectCanvas = document.createElement("canvas");
						const rectCtx = rectCanvas.getContext("2d");

						rectCanvas.width = obj.width * obj.scaleX;
						rectCanvas.height = obj.height * obj.scaleY;

						// object has a gradient fill?
						if (
							obj.fill &&
							typeof obj.fill === "object" &&
							obj.fill.type === "linear"
						) {
							// gradient fills (like feather masks)
							const gradient = obj.fill;
							const coords = gradient.coords;
							const colorStops = gradient.colorStops;

							const scaleX = rectCanvas.width / canvas.width;
							const scaleY = rectCanvas.height / canvas.height;

							// create a linear gradient with scaled coordinates
							const canvasGradient = rectCtx.createLinearGradient(
								coords.x1 * scaleX,
								coords.y1 * scaleY,
								coords.x2 * scaleX,
								coords.y2 * scaleY
							);

							// add color stops
							colorStops.forEach((stop) => {
								canvasGradient.addColorStop(stop.offset, stop.color);
							});

							rectCtx.fillStyle = canvasGradient;
						} else {
							// solid color fills
							rectCtx.fillStyle = obj.fill;
						}

						rectCtx.fillRect(0, 0, rectCanvas.width, rectCanvas.height);

						// determine layer name based on object properties
						let layerName = `Rectangle Layer ${i + 1}`;
						if (obj === featherMask) {
							layerName = "Feather Mask";
							// debug gradient information
							if (
								obj.fill &&
								typeof obj.fill === "object" &&
								obj.fill.type === "linear"
							) {
								console.log("Feather mask gradient:", {
									coords: obj.fill.coords,
									colorStops: obj.fill.colorStops,
									rectCanvasWidth: rectCanvas.width,
									rectCanvasHeight: rectCanvas.height,
									canvasWidth: canvas.width,
									canvasHeight: canvas.height,
									scaleX: rectCanvas.width / canvas.width,
									scaleY: rectCanvas.height / canvas.height
								});
							}
						} else if (obj === backgroundRect) {
							layerName = "Background";
						}

						psd.children.push({
							name: layerName,
							left: obj.left,
							top: obj.top,
							canvas: rectCanvas,
							opacity: obj.opacity || 1,
							blendMode: "normal"
						});
					}
				}

				// generate psd
				const psdData = agPsd.writePsd(psd, { invalidateTextLayers: true });

				const blob = new Blob([psdData], { type: "application/octet-stream" });
				const url = URL.createObjectURL(blob);
				const link = document.createElement("a");
				link.href = url;
				const sourceName = isActorImage
					? actorImageFilename
					: mainImageFilename;
				const baseName = sanitizeBaseName(
					sourceName || (isActorImage ? "actor-image" : "featured-image")
				);
				link.download = `${baseName}.psd`;
				link.click();

				// clean up
				URL.revokeObjectURL(url);
			} catch (error) {
				console.error("Error generating PSD:", error);
				showNotification("Error generating PSD file. Please try again.", {
					type: "error"
				});
			} finally {
				// restore button state
				exportButton.textContent = originalText;
				exportButton.disabled = false;
			}
		});

	// parse color string to rgb object
	function parseColor(colorStr) {
		if (colorStr.startsWith("#")) {
			const r = parseInt(colorStr.slice(1, 3), 16);
			const g = parseInt(colorStr.slice(3, 5), 16);
			const b = parseInt(colorStr.slice(5, 7), 16);
			return { r, g, b };
		} else if (colorStr.startsWith("rgb")) {
			const matches = colorStr.match(/\d+/g);
			if (matches && matches.length >= 3) {
				return {
					r: parseInt(matches[0]),
					g: parseInt(matches[1]),
					b: parseInt(matches[2])
				};
			}
		}
		// default to black if parsing fails
		return { r: 0, g: 0, b: 0 };
	}

	// get full font name for ps compatibility
	function getFullFontName(fontFamily) {
		const fontMap = {
			Arial: "ArialMT",
			arial: "ArialMT",
			"Arial Black": "Arial-BlackMT",
			"arial black": "Arial-BlackMT",
			"Arial Narrow": "ArialNarrowMT",
			"arial narrow": "ArialNarrowMT",
			Times: "TimesNewRomanPSMT",
			times: "TimesNewRomanPSMT",
			"Times New Roman": "TimesNewRomanPSMT",
			"times new roman": "TimesNewRomanPSMT",
			Courier: "CourierMT",
			courier: "CourierMT",
			"Courier New": "CourierNewPSMT",
			"courier new": "CourierNewPSMT",
			Georgia: "Georgia",
			georgia: "Georgia",
			Verdana: "Verdana",
			verdana: "Verdana",
			Tahoma: "Tahoma",
			tahoma: "Tahoma",
			"Trebuchet MS": "TrebuchetMS",
			"trebuchet ms": "TrebuchetMS",
			Impact: "Impact",
			impact: "Impact",
			"Comic Sans MS": "ComicSansMS",
			"comic sans ms": "ComicSansMS",
			"Lucida Console": "LucidaConsole",
			"lucida console": "LucidaConsole",
			"Lucida Sans Unicode": "LucidaSansUnicode",
			"lucida sans unicode": "LucidaSansUnicode",
			Palatino: "Palatino",
			palatino: "Palatino",
			Garamond: "Garamond",
			garamond: "Garamond",
			Bookman: "Bookman",
			bookman: "Bookman",
			"Avant Garde": "AvantGarde",
			"avant garde": "AvantGarde",
			Helvetica: "Helvetica",
			helvetica: "Helvetica",
			Futura: "Futura",
			futura: "Futura",
			Optima: "Optima",
			optima: "Optima",
			Bodoni: "Bodoni",
			bodoni: "Bodoni",
			Didot: "Didot",
			didot: "Didot",
			Copperplate: "Copperplate",
			copperplate: "Copperplate",
			"Brush Script MT": "BrushScriptMT",
			"brush script mt": "BrushScriptMT",
			Papyrus: "Papyrus",
			papyrus: "Papyrus",
			Chalkduster: "Chalkduster",
			chalkduster: "Chalkduster",
			"Marker Felt": "MarkerFelt",
			"marker felt": "MarkerFelt",
			"American Typewriter": "AmericanTypewriter",
			"american typewriter": "AmericanTypewriter",
			Baskerville: "Baskerville",
			baskerville: "Baskerville",
			"Hoefler Text": "HoeflerText",
			"hoefler text": "HoeflerText",
			"Snell Roundhand": "SnellRoundhand",
			"snell roundhand": "SnellRoundhand",
			Zapfino: "Zapfino",
			zapfino: "Zapfino",
			"Zapf Dingbats": "ZapfDingbats",
			"zapf dingbats": "ZapfDingbats"
		};

		// return the mapped font name or the original if not found
		return fontMap[fontFamily] || fontFamily;
	}

	function loadOverlayClone(name) {
		return new Promise((resolve) => {
			fabric.Image.fromURL(`/overlays/${name}`, (img) => {
				img.set({
					selectable: true,
					hasControls: true,
					hasBorders: true,
					lockMovementX: false,
					lockMovementY: false,
					originX: "left",
					originY: "top"
				});
				resolve(img);
			});
		});
	}

	// overlay selection (per-image in batch mode; use Apply to All to broadcast)
	document
		.getElementById("overlays")
		.addEventListener("change", async function (e) {
			const selectedOverlay = e.target.value;

			if (batchMode && batchImages.length > 0) {
				const state = batchImages[activeBatchIndex];
				if (selectedOverlay !== "default") {
					const img = await loadOverlayClone(selectedOverlay);
					state.overlayImage = img;
					state.overlayName = selectedOverlay;
					overlayImage = img;
				} else {
					state.overlayImage = null;
					state.overlayName = null;
					overlayImage = null;
				}
				moveToTop(overlayImage);
				customRender();
				refreshActiveThumbnail();
				return;
			}

			if (selectedOverlay !== "default") {
				fabric.Image.fromURL(`/overlays/${selectedOverlay}`, (img) => {
					img.set({
						selectable: true,
						hasControls: true,
						hasBorders: true,
						lockMovementX: false,
						lockMovementY: false,
						originX: "left",
						originY: "top"
					});
					overlayImage = img;
					moveToTop(overlayImage);
					customRender();
				});
			} else {
				if (overlayImage) {
					canvas.remove(overlayImage);
					overlayImage = null;
				}
				customRender();
			}
		});

	function loadLogoClone(name) {
		return new Promise((resolve) => {
			fabric.Image.fromURL(`/logos/${name}`, (img) => {
				img.set({
					selectable: true,
					hasControls: true,
					hasBorders: true,
					lockMovementX: false,
					lockMovementY: false,
					originX: "right",
					originY: "bottom",
					top: 570,
					left: 1170
				});
				resolve(img);
			});
		});
	}

	// logos (per-image in batch mode; use Apply to All to broadcast)
	document.getElementById("logos").addEventListener("change", async function (e) {
		const selectedLogo = e.target.value;

		if (batchMode && batchImages.length > 0) {
			const state = batchImages[activeBatchIndex];
			if (selectedLogo !== "default") {
				const img = await loadLogoClone(selectedLogo);
				state.logoImage = img;
				state.logoName = selectedLogo;
				logoImage = img;
			} else {
				state.logoImage = null;
				state.logoName = null;
				logoImage = null;
			}
			moveToTop(logoImage);
			customRender();
			refreshActiveThumbnail();
			return;
		}

		if (selectedLogo !== "default") {
			fabric.Image.fromURL(`/logos/${selectedLogo}`, (img) => {
				img.set({
					selectable: true,
					hasControls: true,
					hasBorders: true,
					lockMovementX: false,
					lockMovementY: false,
					originX: "right",
					originY: "bottom",
					top: 570,
					left: 1170
				});
				logoImage = img;
				moveToTop(logoImage);
				customRender();
			});
		} else {
			if (logoImage) {
				canvas.remove(logoImage);
				logoImage = null;
			}
			customRender();
		}
	});

	const textOptionsToggle = document.getElementById("text-options-toggle");
	const textOptionsMenu = document.getElementById("text-options-menu");

	textOptionsToggle.addEventListener("click", () => {
		textOptionsToggle.classList.toggle("active");
		textOptionsMenu.classList.toggle("show");
	});

	// alignments
	document.getElementById("align-left").addEventListener("click", function () {
		alignText("left");
	});

	document
		.getElementById("align-center")
		.addEventListener("click", function () {
			alignText("center");
		});

	document.getElementById("align-right").addEventListener("click", function () {
		alignText("right");
	});

	function alignText(alignment) {
		const activeObject = canvas.getActiveObject();
		if (
			activeObject &&
			(activeObject.type === "i-text" || activeObject.type === "textbox")
		) {
			activeObject.set("textAlign", alignment);
			canvas.renderAll();
		}
	}

	// =========================================================================
	// batch mode
	// =========================================================================

	function makeBatchState(src, fabricImg, filename) {
		mainImageOptions(fabricImg);
		return {
			id: uid("img"),
			src,
			filename: filename || null,
			mainImage: fabricImg,
			overlayImage: null,
			overlayName: null,
			logoImage: null,
			logoName: null,
			textBoxes: [],
			featherMask: null,
			feather: "none"
		};
	}

	function loadFabricImage(src) {
		return new Promise((resolve) => {
			fabric.Image.fromURL(src, (img) => resolve(img));
		});
	}

	function readFileAsDataUrl(file) {
		return new Promise((resolve, reject) => {
			const reader = new FileReader();
			reader.onload = (e) => resolve(e.target.result);
			reader.onerror = reject;
			reader.readAsDataURL(file);
		});
	}

	async function handleBatchUpload(files) {
		const newStates = [];
		for (const file of files) {
			try {
				const dataUrl = await readFileAsDataUrl(file);
				const img = await loadFabricImage(dataUrl);
				const state = makeBatchState(dataUrl, img, file.name);
				newStates.push(state);
			} catch (err) {
				console.error("Failed to load batch image:", err);
			}
		}

		batchImages.push(...newStates);
		if (activeBatchIndex === -1 && batchImages.length > 0) {
			switchToBatchImage(0);
		} else {
			renderThumbnails();
		}
		updateBatchCount();
		fileInput.value = "";
	}

	function switchToBatchImage(index) {
		if (!batchMode) return;
		if (index < 0 || index >= batchImages.length) return;
		canvas.discardActiveObject();
		activeBatchIndex = index;
		const state = batchImages[index];
		mainImage = state.mainImage;
		overlayImage = state.overlayImage;
		logoImage = state.logoImage;
		textBoxes = state.textBoxes;
		featherMask = state.featherMask;

		// reflect this image's selections in the dropdowns
		const overlaysSel = document.getElementById("overlays");
		const logosSel = document.getElementById("logos");
		const featherSel = document.getElementById("feather");
		if (overlaysSel) overlaysSel.value = state.overlayName || "default";
		if (logosSel) logosSel.value = state.logoName || "default";
		if (featherSel) featherSel.value = state.feather || "none";

		customRender();
		renderThumbnails();
	}

	function updateBatchCount() {
		if (batchCountEl) batchCountEl.textContent = batchImages.length;
	}

	function snapshotLiveCanvas() {
		return canvas.toDataURL({
			format: "png",
			quality: 0.7,
			multiplier: 0.15
		});
	}

	function snapshotInactiveState(state) {
		// build a temporary static canvas and render only this state's objects.
		// objects only exist in this state (not on the live canvas), so it's safe
		// to add/remove without disturbing the live canvas.
		const off = document.createElement("canvas");
		off.width = 1200;
		off.height = 600;
		const tempCanvas = new fabric.StaticCanvas(off, {
			width: 1200,
			height: 600,
			backgroundColor: "white",
			renderOnAddRemove: false
		});

		const bg = state.mainImage
			? new fabric.Rect({
					left: state.mainImage.left || 0,
					top: state.mainImage.top || 0,
					width: state.mainImage.width * (state.mainImage.scaleX || 1),
					height: state.mainImage.height * (state.mainImage.scaleY || 1),
					fill: "white",
					selectable: false,
					evented: false
			  })
			: null;
		if (bg) tempCanvas.add(bg);
		if (state.mainImage) tempCanvas.add(state.mainImage);
		if (state.overlayImage) tempCanvas.add(state.overlayImage);
		if (state.logoImage) tempCanvas.add(state.logoImage);
		if (state.featherMask) tempCanvas.add(state.featherMask);
		state.textBoxes.forEach((t) => tempCanvas.add(t));
		tempCanvas.renderAll();

		const url = tempCanvas.toDataURL({
			format: "png",
			quality: 0.7,
			multiplier: 0.15
		});

		// detach so each object loses its canvas binding cleanly before disposal
		tempCanvas.getObjects().slice().forEach((o) => tempCanvas.remove(o));
		tempCanvas.dispose();
		return url;
	}

	function generateThumbnail(state, index) {
		if (index === activeBatchIndex) return snapshotLiveCanvas();
		return snapshotInactiveState(state);
	}

	function renderThumbnails() {
		if (!batchThumbnailsEl) return;
		batchThumbnailsEl.innerHTML = "";
		batchImages.forEach((state, i) => {
			const wrap = document.createElement("div");
			wrap.className = "thumbnail" + (i === activeBatchIndex ? " active" : "");
			wrap.dataset.index = i;

			const img = document.createElement("img");
			img.src = generateThumbnail(state, i);
			wrap.appendChild(img);

			const idx = document.createElement("span");
			idx.className = "thumbnail-index";
			idx.textContent = i + 1;
			wrap.appendChild(idx);

			const remove = document.createElement("button");
			remove.className = "thumbnail-remove";
			remove.textContent = "×";
			remove.title = "Remove image";
			remove.addEventListener("click", (e) => {
				e.stopPropagation();
				removeBatchImage(i);
			});
			wrap.appendChild(remove);

			wrap.addEventListener("click", () => switchToBatchImage(i));
			batchThumbnailsEl.appendChild(wrap);
		});
	}

	function removeBatchImage(index) {
		if (!batchImages[index]) return;
		batchImages.splice(index, 1);
		if (batchImages.length === 0) {
			activeBatchIndex = -1;
			mainImage = undefined;
			overlayImage = undefined;
			logoImage = null;
			textBoxes = [];
			featherMask = null;
			canvas.clear();
			renderThumbnails();
			updateBatchCount();
			return;
		}
		const next = Math.min(index, batchImages.length - 1);
		switchToBatchImage(next);
		updateBatchCount();
	}

	function setBatchMode(on) {
		batchMode = on;
		document.body.classList.toggle("batch-mode", on);
		fileInput.multiple = on;

		const resizeBtn = document.getElementById("resize");
		const applyBtn = document.getElementById("apply-to-all");
		const zipBtn = document.getElementById("export-zip");
		const exportBtn = document.getElementById("export");

		if (on) {
			const actorCheckbox = document.getElementById("isActorImage");
			if (actorCheckbox.checked) actorCheckbox.click();
			actorCheckbox.disabled = true;
			batchPanel.style.display = "flex";
			resizeBtn.style.display = "inline-block";
			applyBtn.style.display = "inline-block";
			zipBtn.style.display = "inline-block";
			exportBtn.style.display = "none";
		} else {
			document.getElementById("isActorImage").disabled = false;
			batchPanel.style.display = "none";
			resizeBtn.style.display = "none";
			applyBtn.style.display = "none";
			zipBtn.style.display = "none";
			exportBtn.style.display = "";

			batchImages = [];
			activeBatchIndex = -1;
			mainImage = undefined;
			overlayImage = undefined;
			logoImage = null;
			textBoxes = [];
			featherMask = null;
			canvas.clear();
			renderThumbnails();
			updateBatchCount();
		}
	}

	document
		.getElementById("isBatchMode")
		.addEventListener("change", function (e) {
			setBatchMode(e.target.checked);
		});

	document.getElementById("batch-clear").addEventListener("click", async () => {
		if (batchImages.length === 0) return;
		const ok = await showConfirm(
			`Remove all ${batchImages.length} batch images? This can't be undone.`,
			{
				title: "Clear batch?",
				confirmText: "Yes, remove all",
				cancelText: "Keep them",
				tone: "danger"
			}
		);
		if (!ok) return;
		batchImages = [];
		activeBatchIndex = -1;
		mainImage = undefined;
		overlayImage = undefined;
		logoImage = null;
		textBoxes = [];
		featherMask = null;
		canvas.clear();
		renderThumbnails();
		updateBatchCount();
		showNotification("Batch cleared.", { type: "info" });
	});

	// auto-refresh thumbnails when active image is edited
	canvas.on("object:modified", () => {
		if (batchMode && activeBatchIndex >= 0) {
			// refresh just the active thumbnail
			refreshActiveThumbnail();
		}
	});

	function refreshActiveThumbnail() {
		const wrap = batchThumbnailsEl.querySelector(
			`.thumbnail[data-index="${activeBatchIndex}"]`
		);
		if (!wrap) return;
		const img = wrap.querySelector("img");
		if (img) img.src = snapshotLiveCanvas();
	}

	// apply to all: push selected element to every image (clones onto images
	// that don't have one yet, updates ones that do)
	document
		.getElementById("apply-to-all")
		.addEventListener("click", async function () {
			if (!batchMode) return;
			if (batchImages.length < 2) {
				showNotification("Add at least 2 images to use Apply to All.", {
					type: "warning"
				});
				return;
			}
			const active = canvas.getActiveObject();
			if (!active) {
				showNotification(
					"Select an element first (text, overlay, logo, or main image).",
					{ type: "warning" }
				);
				return;
			}

			const activeState = batchImages[activeBatchIndex];
			const btn = this;
			btn.disabled = true;

			try {
				if (active.type === "i-text" || active.type === "textbox") {
					if (!active._batchId) active._batchId = uid("text");
					await syncTextboxToAll(active, activeState);
				} else if (active === activeState.overlayImage) {
					await syncOverlayToAll(active, activeState);
				} else if (active === activeState.logoImage) {
					await syncLogoToAll(active, activeState);
				} else if (active === activeState.mainImage) {
					syncMainImageToAll(active, activeState);
				} else {
					showNotification("This element type can't be applied to all yet.", {
						type: "warning"
					});
					return;
				}

				customRender();
				renderThumbnails();
				showNotification(
					`Synced to ${batchImages.length - 1} other image${
						batchImages.length === 2 ? "" : "s"
					}.`,
					{ type: "success" }
				);
			} finally {
				btn.disabled = false;
			}
		});

	async function syncTextboxToAll(active, activeState) {
		const props = pickTextProps(active);
		for (const state of batchImages) {
			if (state === activeState) continue;
			const match = state.textBoxes.find((t) => t._batchId === active._batchId);
			if (match) {
				match.set(props);
			} else {
				const clone = buildTextbox(
					active.text,
					active.left,
					active.top,
					active.fontSize,
					active.fontFamily,
					active.fill,
					active.fontWeight === "bold",
					active._batchId
				);
				clone.set(props);
				state.textBoxes.push(clone);
			}
		}
	}

	async function syncOverlayToAll(active, activeState) {
		const props = pickPositionProps(active);
		const overlayName = activeState.overlayName;
		for (const state of batchImages) {
			if (state === activeState) continue;
			if (state.overlayImage) {
				state.overlayImage.set(props);
				if (overlayName) state.overlayName = overlayName;
			} else if (overlayName) {
				const clone = await loadOverlayClone(overlayName);
				clone.set(props);
				state.overlayImage = clone;
				state.overlayName = overlayName;
			}
		}
	}

	async function syncLogoToAll(active, activeState) {
		const props = pickPositionProps(active);
		const logoName = activeState.logoName;
		for (const state of batchImages) {
			if (state === activeState) continue;
			if (state.logoImage) {
				state.logoImage.set(props);
				if (logoName) state.logoName = logoName;
			} else if (logoName) {
				const clone = await loadLogoClone(logoName);
				clone.set(props);
				state.logoImage = clone;
				state.logoName = logoName;
			}
		}
	}

	function syncMainImageToAll(active, activeState) {
		const props = pickPositionProps(active);
		batchImages.forEach((state) => {
			if (state === activeState || !state.mainImage) return;
			state.mainImage.set(props);
		});
	}

	function pickPositionProps(o) {
		return {
			left: o.left,
			top: o.top,
			scaleX: o.scaleX,
			scaleY: o.scaleY,
			angle: o.angle,
			originX: o.originX,
			originY: o.originY
		};
	}

	function pickTextProps(o) {
		return {
			...pickPositionProps(o),
			text: o.text,
			fill: o.fill,
			fontSize: o.fontSize,
			fontFamily: o.fontFamily,
			fontWeight: o.fontWeight,
			textAlign: o.textAlign,
			width: o.width
		};
	}

	// export zip: render every image and bundle as a single zip
	document
		.getElementById("export-zip")
		.addEventListener("click", async function () {
			if (!batchMode || batchImages.length === 0) return;
			if (typeof JSZip === "undefined") {
				showNotification("ZIP library failed to load.", { type: "error" });
				return;
			}

			const btn = this;
			const original = btn.textContent;
			btn.textContent = "Zipping...";
			btn.disabled = true;
			canvas.discardActiveObject();
			const previousIndex = activeBatchIndex;

			try {
				const zip = new JSZip();
				const usedNames = new Set();
				for (let i = 0; i < batchImages.length; i++) {
					switchToBatchImage(i);
					await new Promise((r) => requestAnimationFrame(r));
					const dataUrl = canvas.toDataURL({
						format: "png",
						quality: 1,
						width: 1200,
						height: 600,
						backgroundColor: "white"
					});
					const base64 = dataUrl.split(",")[1];

					const state = batchImages[i];
					const fallback = `featured-image-${String(i + 1).padStart(2, "0")}`;
					const base = sanitizeBaseName(state.filename || fallback);
					let filename = `${base}.png`;
					let dupCount = 1;
					while (usedNames.has(filename)) {
						filename = `${base}-${++dupCount}.png`;
					}
					usedNames.add(filename);
					zip.file(filename, base64, { base64: true });
				}

				const blob = await zip.generateAsync({ type: "blob" });
				const url = URL.createObjectURL(blob);
				const link = document.createElement("a");
				link.href = url;
				link.download = `featured-images-${Date.now()}.zip`;
				link.click();
				URL.revokeObjectURL(url);
				showNotification(
					`Exported ${batchImages.length} image${
						batchImages.length === 1 ? "" : "s"
					} to ZIP.`,
					{ type: "success" }
				);
			} catch (err) {
				console.error("Batch export failed:", err);
				showNotification("Batch export failed. See console for details.", {
					type: "error"
				});
			} finally {
				if (previousIndex >= 0) switchToBatchImage(previousIndex);
				btn.textContent = original;
				btn.disabled = false;
			}
		});
});
